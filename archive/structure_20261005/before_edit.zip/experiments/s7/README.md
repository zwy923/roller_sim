# experiments/s7：基线能不能让每块料独立测量（2026-10-05）

结果和分析在项目根目录 [EXPERIMENTS.md](../../EXPERIMENTS.md) 第 S7 节；推后的问题在 [TODO.md](../../TODO.md)。

| 文件 / 目录 | 是什么 |
|---|---|
| `s7_jobs.py` | 生成任务清单：基线（默认参数）× 四种布料 × 种子。`ideal` 是整条线读真值的对照，`creep15`、`creep075` 是给料带慢走减速的两档 |
| `s7_analyze.py` | 批量报告：导入共用的 [`singulator/audit.py`](../../singulator/audit.py)，统计逐块独立测量、失败原因及批次状态。旧完整结果可直接重算。口径见 [计量段设计](../../designs/station/DESIGN.md#独立测量验收口径) |
| `s7_analyze_checks.py` | 共用审计的自检（16 项，构造结果，不跑物理），包含撤销记录、JSON / CLI 摘要和主指标与后续检查分离 |
| `s7_feed.py` | 给料机头做了什么：每次放料下了几块、两块过边隔多久、多久挡住 S1、一起下去的料后来怎样 |
| `out_valid_b/`、`out_valid_c/` | **结论用的批**：修正后重跑 7101–7130，另用新种子 7131–7160 扩大验证；当轮仿真源码的 `source_sha` 以 `f6794775` 开头 |
| `out_valid/` | 首轮验证（种子 7101–7130），修 S1 失效误报之前的代码（`5414afef`）：6 批被误报停线 |
| `out_small60/` | 小批定位，出口 0.60 m，种子 7001–7010（`5414afef`） |
| `out_small/` | 小批定位，出口 0.65 m（定 0.60 之前），同样的种子：`baseline`、`ideal`、`creep15`、`creep075` |
| `out_s6check/` | 用当轮仿真代码加 `S6_LINE` 重跑第 S6 节的 24 批，核对默认值改了之后旧结果还能复现 |
| `changes_code_20261005.diff` | S7 仿真阶段的代码改动（`experiments/s6/candidate3` → 当时项目根目录），不包含随后共用审计的收尾修改 |
| `_scratch/` | 过程文件：日志、任务清单、跑批用的代码副本（`candidate`，共用审计收尾前的源码）、核对用的两个小脚本（`_recount.py` 独立重数，`_cmp_runs.py` 两次运行逐项比较）、自检记录 `checks_root_20261005.log`。可以整个删掉 |

复现命令见第 S7 节末尾。

# 煤矸混合来料模型（2026-09-24）

当前默认 `--material-model composition`，版本 `coal_gangue_dry_v1`。这是**组成与质量守恒的干态等效模型，未经现场标定**。只修改来料材料生成与输出；尺寸、形状族、设备、控制、摩擦均沿用当前模型。相同种子、相同 `gangue_fraction` 下，原有几何与初始布置随机序列保持不变。

## 组成口径

每块先抽类别、再抽块内矸石端元的质量分数，然后由端元密度算整块密度。端元指低密度煤基质和富矿物矸石岩，不是纯碳与纯矿物；煤端元也可含原生矿物，矸石端元也可含残煤。因此这里的比例不能当作固定碳、灰分、元素分析或矿物化验结果。

| 类别 | 默认按块数抽样概率 | 块内矸石端元干质量分数（均匀抽样） |
|---|---:|---:|
| coal，煤为主 | 45% | 0–10% |
| middlings，夹矸煤/连生体 | 25% | 10–80% |
| gangue，矸石为主 | 30% | 80–100% |

**以上概率、分类边界、均匀分布全部是显式工程假设，没有矿区样本支持，也不是行业分类标准。** 默认保留原来 30% 的矸石类别概率，在余下类别中增加 25% 的夹矸煤。每批仍按现有配置产生 3–5 块（默认 5 块），不强塞固定数量的每一类；小批次可能没有某一类。

`--gangue-fraction` 是矸石为主类别的**块数概率**，`--middlings-fraction` 是连生体类别的块数概率，两者之和不得超过 1。整批真实生成的端元质量比例在 `feed_material.mass_fractions` 中按各块质量加权，不能用块数比例替代。

## 密度和重量

煤端元有效颗粒密度暂沿用 1250–1450 kg/m³，矸石端元沿用 2250–2700 kg/m³，均匀抽样。这些范围仍是待标定假设；不是文献给出的本矿区分布，也不是堆积密度。可用 `--coal-density-min/max` 和 `--gangue-density-min/max` 替换为实测边界。

令块内干质量分数为 `wc + wg = 1`，端元有效密度为 `ρc, ρg`，按端元体积可加近似：

```
ρ = 1 / (wc / ρc + wg / ρg)
V = 实际生成凸包体积
m = ρ × V
煤端元质量 = wc × m；矸石端元质量 = wg × m
重力 = m × 9.81 N
```

这里用质量分数的调和混合公式，不能使用 `wc*ρc + wg*ρg`。质量不独立随机指定，否则会与几何体积、密度矛盾。生成器即给出质量；仿真编译后用 MuJoCo 实际刚体质量统一更新各端元质量和重力，实际动力学使用同一密度。

`result.json` 每块记录 `material_model`、`density`（kg/m³）、`volume_m3`、`mass_kg`、`weight_N`，以及 `composition` 中的质量分数、体积分数、端元密度、端元质量。整批的 `feed_material` 保存总质量、总重力、类别计数与实得质量比例。颜色随矸石体积分数连续变化，只用于查看组成，不是矿物纹理或识别模型。

## 证据与边界

- [USGS：Coal—A Complex Natural Resource](https://pubs.usgs.gov/circ/c1143/html/text.html) 说明原煤可以同时含夹层岩、顶底板岩、脉状及分散矿物；支持使用煤、矸与连生体的概念，不提供本模型默认概率。
- [煤浮选尾矿矿物赋存实测研究，ACS Omega 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9366987/) 给出跨多个密度级的煤样及矿物赋存分析。它是细粒样本，**不能把其密度级产率搬到本项目 300–500 mm 块料**。
- [Handbook of Mineralogy：高岭石](https://www.handbookofmineralogy.org/pdfs/kaolinite.pdf) 的实测矿物密度约 2.61–2.68 g/cm³；[石英](https://www.handbookofmineralogy.org/pdfs/quartz.pdf) 约 2.65 g/cm³。它们只支持富矿物端元密度的量级，不能验证多孔含碳矸石的具体密度分布。

没有实测含水率，因此本版明确为**干态**，不杜撰水分、灰分、石英/高岭石比例。端元孔隙效应仅隐含在有效密度中，没有额外添加孔隙；不模拟含水变化、破碎、内部夹层、局部质心偏移及非均匀惯量。每块仍为均质等效刚体。要声称还原真实来料，需该粒级样本的逐块质量与体积、煤矸连生比例、含水率和组成测量。

## 使用与检查

```powershell
python plough.py --no-video
python plough.py --no-video --gangue-fraction 0 --middlings-fraction 1  # 全部为连生体类别
python plough.py --no-video --material-model legacy_binary           # 旧二元抽样策略
python checks/material_checks.py
```

缺少 `material_model` 的旧配置按 `legacy_binary` 处理，以保留旧材料采样行为。新旧材料总体不同，历史卡堵率等结果不能直接合并；本次只检查生成、质量守恒及短时运行，不重跑或宣称设备性能。

"""Short stop-start feed belt with a step-down transfer in front of the plough (third version 2026-09-23; the
line's feed since the gated mainline was deleted, 2026-09-30).

    feed belt (whole batch laid on it, own drive), its top feeder_step ABOVE the main belt
    -> main belt, straight run of feeder_gap -> plough face -> lane (0.65 m)

Why the step. On a feed belt butted flat to the main belt (the second version) a lump straddling the joint
is held or dragged by friction on two surfaces, so hold-back had to be judged by the FRONT edge; the row
plan then pulled in every lump the feed travel brought near the joint, and echelon layouts went five in
a row (all 77 five-lump rows in 1000 seeds, EXPERIMENTS.md). With the feed belt a step above the main belt,
a lump overhanging the head edge still lies wholly on the feed belt -- the overhang is in the air, clear of
the main belt -- until its CENTROID passes the edge; then it tips onto the main belt, which takes it away.
Hold-back is gravity, not friction, and it is by centroid for every lump: a lump beside the one that goes
stays behind even when its front already overhangs.

Hardware as modelled:
  * feed belt as wide as the main belt (belt_w, same skirts), feeder_len long, its top feeder_step above the
    main belt top, with a sharp head edge at x1 (the default). Since 2026-09-30 the transfer as
    built can be modelled instead (user: 高差和交接位置做成可调): a driven head drum (feeder_head_d) whose top
    is tangent to the flat run at x1, the main belt starting over its own tail pulley (feeder_tail_d) at
    x_lower = x1 + feeder_handover, which must leave the two clear of each other (min_handover). With a real
    drum and a small step the belts stand 0.1-0.25 m apart and a lump spans both; the bench trial
    (singulator/trial.py, designs/transfer_trial/) is where that is measured;
  * its own force-limited drive with a finite brake: feeder_speed on approach, feeder_creep_speed once the
    leading lump's centroid is within CREEP_ZONE of the edge;
  * a drop beam: a light beam across the belt BEAM_X past the edge at half the step height. A lump still
    lying on the feed belt overhangs above it; one that tips cuts it. The beam is the stop signal;
  * feeder_gap of main belt between the edge and the plough start: at least the longest plan extent of a
    flat-lying lump plus the creep stopping distance, so a lump held up at the plough never still lies on
    the feed belt.

Control (one lump at a time; the camera only sets the creep, the beam stops):
  1. the whole batch is laid on the feed belt;
  2. a release runs the feed belt at feeder_speed, creeps once the leading lump's centroid is within
     CREEP_ZONE of the edge, and stops as soon as the beam is cut;
  3. a lump is released once its centroid is past the edge. Every lump released between the start of one
     release and the start of the next belongs to it; one that goes after the stop is counted
     ('after_stop'): its centroid was level with the one that went, within the stopping distance;
  4. the next release starts once every released lump is through the funnel -- its rear edge past the lane
     entry, where the lane's outer wall starts (lane_out_start), or off the belt -- and the plough face is
     back home. Until 2026-09-24 it waited for the tail to pass the lane EXIT, 0.82 m further on (user: go as
     soon as the lump is in the straight lane). The next lump cannot catch up: it still has the creep zone,
     the drop and feeder_gap + the face to cover, over 1.5 m at no more than the main belt speed;
  5. fallbacks, counted: a released lump left hanging on the edge (rear still on the feed belt) with no
     progress for feeder_stall_s gets a creep jog until its rear is CLEAR past the edge; a release whose
     lump went without cutting the beam stops BEAM_MISS_S after it went;
  6. while the station holds the section upstream, the feed belt brakes and this controller is frozen
     (pause / resume); its clocks do not run during the hold.

Predictive release (--feeder-release predict, the default since 2026-09-24, user: as many lumps as possible
without piling them up in the funnel; 'lane' is item 4 above). Item 4 is replaced and a staging step added:
  4'. between releases the feed belt STAGES the next lump: once the released lumps are off the edge it runs
      until the leading queued centroid is at the creep zone, so a release only has the creep left. A release
      starts only from there, so the decision below always looks the same short time ahead;
  5'. the next release starts as soon as it cannot put two lumps in the funnel: by the time the next lump's
      front reaches the funnel mouth (the plough start, x of P0), every lump released before must have its
      rear past the lane entry, with RELEASE_MARGIN_S to spare. How long they take is predicted from the
      camera: each one's centroid speed over the last feeder_stall_s, but no faster than V_FACE in the
      funnel while the plough face is still ahead of a lump that reaches above the lane band; a lump slower
      than V_STALL holds the release, and so does one still lying across the drop beam (it would stop the
      new release at once). The face must be home, as before.

--sensing vision (the default, 2026-09-30): the controller reads the cameras' objects (outline centroid, not the
centre of mass) and the debounced beam, and judges by region instead of by track id -- see _observe_vision.
--sensing oracle gives it one object per lump with the true centroid and hull (observe).

Nothing here is calibrated. Both belts are plates with a prescribed surface velocity.
"""
import math

import numpy as np

from .perception import CONF_OK

DEFAULTS = dict(feeder_speed=.10, feeder_creep_speed=.03, feeder_step=.10, feeder_len=2.2, feeder_gap=.80,
                feeder_ramp_s=.30, feeder_stall_s=.50, feeder_force_max=3000.)
# The transfer as built (2026-09-30, user: 别把 50 mm 高差定死; 高差和交接位置做成可调). 0 = the idealised sharp
# head edge right over the main belt's square start (the default):
HEAD_DEFAULTS = dict(feeder_head_d=0.,      # m: head drum diameter of the feed belt (belt wrapped round it)
                     feeder_tail_d=0.,      # m: tail pulley diameter of the belt below (its start)
                     feeder_handover=0.)    # m: from the head drum's top tangent to where the belt below runs flat
EQUIP_CLEAR = .01    # m: the head drum and the tail pulley below keep at least this apart
FRONT_MARGIN = .05   # m: at t = 0 the batch's front edge is this far behind the head edge
REAR_MARGIN = .02    # m: ... and its rear edge at least this far in front of the feed belt's tail end
CREEP_ZONE = .05     # m: creep once the leading centroid is this close to the edge (covers camera error)
BEAM_X = .10         # m: the drop beam lies this far past the head edge, at half the step height
BEAM_MISS_S = 1.     # s: a release whose lump went without cutting the beam stops this long after it went
STAGE_STOP = .016    # m: predictive release: staging stops this far short of the creep zone (stop from 0.10 m/s) ...
STAGE_SLACK = .03    # ... and starts again only if the lead lies this much further back
V_FACE = .15         # m/s: x-speed assumed in the funnel while the plough face is still ahead of a lump
V_STALL = .03        # m/s: a released lump slower than this holds the next release
RELEASE_MARGIN_S = 1.  # s: the next lump reaches the funnel mouth at least this long after the one before has left it
TIP_S = .3           # s: from centroid over the edge to lying on the main belt
CLEAR = .02          # m: a jog runs until the jogged lump's rear edge is this far past the edge
OBS_DT = .01         # s: camera sample
WENT_MARGIN = .05    # m: vision: an object is over the edge once its outline centroid is this far past it
                     # (the camera's centroid is up to ~4 cm off the centre of mass: seed 392, p95 2.6 cm) ...
JUST_WENT = .25      # m: ... and has only just gone while it is less than this past it
JOG_MAX_S = 3.       # s: vision: a hang jog runs at most this long without the beam being cut
STAGE_REACH = .80    # m: vision: objects from this far behind the edge to the lane entry must be recognised


def geometry(cfg, first_x):
    """Feed belt from x0 to the head edge x1, feeder_step above the main belt. first_x: the plough start, the
    first thing downstream that can hold a lump up."""
    for k in DEFAULTS:
        if not math.isfinite(cfg[k]) or cfg[k] <= 0:
            raise ValueError('--%s must be finite and positive' % k.replace('_', '-'))
    for k in HEAD_DEFAULTS:
        if not math.isfinite(cfg.get(k, 0.)) or cfg.get(k, 0.) < 0:
            raise ValueError('--%s must be finite and not negative' % k.replace('_', '-'))
    v, vc, h, gap = cfg['feeder_speed'], cfg['feeder_creep_speed'], cfg['feeder_step'], cfg['feeder_gap']
    R, r, hand = cfg.get('feeder_head_d', 0.) / 2, cfg.get('feeder_tail_d', 0.) / 2, cfg.get('feeder_handover', 0.)
    need = min_handover(h, R, r)
    if hand < need - 1e-9:
        raise ValueError('--feeder-handover %.3f m: the head drum (D %.3f m) and the belt below (tail pulley D %.3f m, '
                         '%.3f m lower) would collide; it needs at least %.3f m' % (hand, 2 * R, 2 * r, h, need))
    if v >= cfg['v_belt']:
        raise ValueError('--feeder-speed %.3g must be below the main belt speed %.3g: the faster main belt is '
                         'what takes a released lump away from the rest' % (v, cfg['v_belt']))
    if vc > v:
        raise ValueError('--feeder-creep-speed %.3g must not exceed --feeder-speed %.3g' % (vc, v))
    span = math.hypot(cfg['size_long_max'], cfg['size_max'])   # plan diagonal of a flat-lying lump, bound
    stop = vc * cfg['feeder_ramp_s'] * (vc / v) / 2 + vc * OBS_DT   # ramp-down from creep + one camera sample
    if gap < hand + span + stop:
        raise ValueError('--feeder-gap %.3f m is shorter than the hand-over (%.3f m) + one lump (%.3f m plan extent) + '
                         'the feed belt stopping distance (%.3f m): a lump held up at the plough could still lie on '
                         'the feed belt' % (gap, hand, span, stop))
    x1 = first_x - gap
    head = {} if not (R or r or hand) else dict(
        head=dict(drum_d_m=2 * R, tail_d_m=2 * r, handover_m=hand, min_handover_m=round(need, 4),
                  drum_centre=[x1, None, round(h - R, 4)] if R else None,
                  tail_centre=[x1 + hand, None, round(-r, 4)] if r else None))
    return dict(x0=x1 - cfg['feeder_len'], x1=x1, length_m=cfg['feeder_len'], width_m=cfg['belt_w'],
                **({} if not hand else dict(x_lower=x1 + hand)), **head,
                gap_to_plough_m=gap, step_m=h, speed_m_s=v, creep_speed_m_s=vc, creep_zone_m=CREEP_ZONE,
                main_to_feeder_speed_ratio=cfg['v_belt'] / v,
                longest_plan_extent_m=round(span, 4), stop_distance_m=round(stop, 4),
                stop_distance_basis='nominal ramp-down from creep plus one sample; not a bound under brake overload',
                beam=dict(x=x1 + hand + BEAM_X, z=h / 2), release_rule='centroid past the head edge (the lump tips)')


def min_handover(h, R, r, clear=EQUIP_CLEAR):
    """Smallest horizontal distance from the head drum's top tangent (radius R, 0 = a sharp edge) to the
    flat start of the belt below (tail pulley radius r, 0 = a square plate end) with the drum and the belt
    below clear of each other. The feed belt top is h above the belt below."""
    if R == 0. and r == 0.:
        return 0.
    if r == 0.:                     # the drum against the square end of the plate below (its top at 0)
        return math.sqrt(max(0., R * R - (h - R) ** 2)) + clear if h < 2 * R else 0.
    # the drum against the tail pulley: centres (0, h - R) and (x, -r)
    dz = h - R + r
    return math.sqrt(max(0., (R + r + clear) ** 2 - dz ** 2))


class Feeder:
    """Lump-by-lump release. The drive itself is a Conveyors motor; this sets its target speed factor."""

    def __init__(self, cfg, d, n):
        self.cfg, self.g, self.n = cfg, d['feeder'], n
        self.lane_in = float(d['lane_out_start'])       # a released lump whose rear is past this is in the lane
        self.creep = self.g['creep_speed_m_s'] / self.g['speed_m_s']
        self.released, self.releases, self.events = [], [], []
        self.phase, self.goal, self.target = 'stopped', 0., 0.
        self.jog = None                                 # the released lump being jogged off the edge
        self.hist = {}                                  # (t, centroid x) per object, feeder_stall_s long
        self.counts = dict(after_stop=0, jogs=0, beam_missed=0)
        self.paused_at, self.held_s, self.miss_shift = None, 0., 0.   # station hold (see pause)
        self.predict = cfg.get('feeder_release', 'lane') == 'predict'
        self.staging = False
        self.vision = cfg.get('sensing', 'vision') == 'vision'   # else the ideal view (--sensing oracle)
        self.lumps_went = set()                         # vision: true lumps over the edge (verification)
        self.miss_streak = 0                            # releases in a row that ended on the beam-miss fallback
        self.across_hist = []                           # vision: (t, centroid x of the most advanced object across the edge)
        self.hang, self.jog_t0 = False, 0.              # vision: a release ended on the beam-miss fallback
        # a lump that went has to cross the hand-over gap before it reaches the beam (dragged at about half the
        # main belt speed while its rear still rests on the head drum): the fallback waits that much longer
        hand = self.g.get('x_lower', self.g['x1']) - self.g['x1']
        self.beam_miss_s = BEAM_MISS_S + (hand / (.5 * cfg['v_belt']) if hand > 0. else 0.)
        if self.predict:
            self.funnel_in, self.bend, self.lane_top = float(d['P0'][0]), float(d['P1'][0]), float(d['lane_top'])
            self.counts['stagings'] = 0

    def waiting(self, k, state, cx):
        """Planned wait (stall bookkeeping only): the lump still lies on the feed belt, centroid behind the edge."""
        return state == 'on_belt' and k not in (self.lumps_went if self.vision else self.released) and cx <= self.g['x1']

    def start(self, t):
        self.releases.append(dict(release=len(self.releases), members=[], after_stop=[], t_start_s=round(t, 3),
                                  t_creep_s=None, t_stop_s=None, stop='', jogs=0))
        self.phase, self.goal, self.jog, self.miss_shift = 'feeding', 1., None, 0.
        self.events.append(dict(t_s=round(t, 3), event='release_start', release=len(self.releases) - 1))

    # ---- station hold ----------------------------------------------------------------------------
    @property
    def paused(self):
        return self.paused_at is not None

    def pause(self, t):
        """The station holds the section upstream of the weigh belt: brake now, re-ramp after the hold."""
        if self.paused_at is None:
            self.paused_at, self.target = t, 0.

    def resume(self, t):
        """End of a hold: the beam-miss clock skips it, and progress is judged afresh."""
        if self.paused_at is None:
            return
        held, self.paused_at = t - self.paused_at, None
        self.held_s += held
        if self.releases and (self.releases[-1]['members'] or 't_first_s' in self.releases[-1]):
            self.miss_shift += held
        self.hist, self.across_hist = {}, []

    def _stop(self, t, why):
        rel = self.releases[-1]
        if rel['t_stop_s'] is None:
            rel['t_stop_s'], rel['stop'] = round(t, 3), why
        self.phase, self.goal = 'stopped', 0.
        self.events.append(dict(t_s=round(t, 3), event='stop', release=rel['release'], why=why))

    # ---- per step ------------------------------------------------------------------------------
    def drive_target(self, dt):
        """Ramped speed factor for the feed belt drive (1 = feeder_speed), advanced one physics step."""
        r = dt / self.cfg['feeder_ramp_s']
        g = self.goal
        self.target = min(g, self.target + r) if g > self.target else max(g, self.target - r)
        return self.target

    # ---- every camera sample --------------------------------------------------------------------
    def _no_progress(self, k, t):
        h, W = self.hist.get(k, []), self.cfg['feeder_stall_s']
        if not h or h[0][0] > t - W + 1e-9:
            return False
        past = next(x for tt, x in reversed(h) if tt <= t - W + 1e-9)
        return h[-1][1] - past < .02 * W

    def in_lane(self, k, view):
        """Through the funnel: rear edge past the lane entry, or no longer on the belt (passed / discharged /
        dropped: not in the view)."""
        return k not in view or view[k]['x0'] > self.lane_in

    def observe(self, t, view, beam_cut, face_home):
        """view: {id: object} -- what the camera reports of every lump or blob still on the machine: 'cx'
        (centroid x), 'x0' / 'x1' (rear / front edge), 'y1' (outer edge), and with --sensing vision 'vx',
        'conf' and 'coasting'. The oracle view (--sensing oracle) is one object per lump, its true centroid
        and hull. beam_cut: the drop beam is blocked; face_home: the plough face is back home."""
        if self.vision:
            return self._observe_vision(t, view, beam_cut, face_home)
        W, x1 = self.cfg['feeder_stall_s'], self.g['x1']
        for k, o in view.items():
            h = self.hist.setdefault(k, [])
            h.append((t, o['cx']))
            while len(h) > 2 and h[1][0] < t - W - .02:
                h.pop(0)
        went = [k for k, o in view.items() if k not in self.released and o['cx'] > x1]
        if went and self.releases:
            rel = self.releases[-1]
            rel['members'] += went
            self.released += went
            late = rel['t_stop_s'] is not None          # after the stop: while braking, waiting or jogging
            if late:
                rel['after_stop'] += went
                self.counts['after_stop'] += len(went)
            self.events.append(dict(t_s=round(t, 3), event='released', release=rel['release'], blocks=went,
                                    after_stop=late))
            rel.setdefault('t_first_s', round(t, 3))
        q = [k for k in view if k not in self.released]
        if self.phase == 'feeding':
            rel = self.releases[-1]
            if self.jog is not None:
                j = self.jog
                if j not in view or view[j]['x0'] > x1 + CLEAR:
                    self.jog = None
                    self._stop(t, 'jog_done')
            elif beam_cut:
                self._stop(t, 'beam')
                self.miss_streak = 0
            elif rel['members'] and t - rel['t_first_s'] - self.miss_shift > self.beam_miss_s:
                self.counts['beam_missed'] += 1
                self.miss_streak += 1
                self._stop(t, 'beam_missed')
            elif not q and not rel['members']:
                self._stop(t, 'feed_belt_empty')
            elif q and self.goal == 1. and max(view[k]['cx'] for k in q) > x1 - CREEP_ZONE:
                self.goal = self.creep
                rel['t_creep_s'] = round(t, 3)
        elif self.phase in ('stopped', 'empty'):
            # a released lump the main belt did not take off the edge: jog it across at creep speed
            hanging = [k for k in self.released if k in view and view[k]['x0'] < x1 < view[k]['x1']
                       and self._no_progress(k, t)]
            if hanging:
                self.jog, self.phase, self.goal, self.staging = hanging[0], 'feeding', self.creep, False
                self.releases[-1]['jogs'] += 1
                self.counts['jogs'] += 1
                self.events.append(dict(t_s=round(t, 3), event='jog', release=self.releases[-1]['release'],
                                        block=hanging[0]))
            elif not q:
                if self.phase != 'empty':
                    self.phase = 'empty'
                    self.events.append(dict(t_s=round(t, 3), event='feed_belt_empty'))
            elif self.predict:
                if face_home and not self.staging and self._staged(view, q) and self._clear_to_release(view, q):
                    self.start(t)
                else:
                    self._stage(t, view, q)
            elif all(self.in_lane(k, view) for k in self.released) and face_home:
                self.start(t)

    # ---- vision: by region, not by track id --------------------------------------------------------
    def _observe_vision(self, t, view, beam_cut, face_home):
        """The same control on what the cameras report. Track ids are no use at the head edge: a lump tipping
        against the one behind it merges with it and splits off again every few frames (seed 4001: 90 new ids
        in 2 s), and a controller keyed on ids takes the lump hanging on the edge for the next one to go. So:
          gone      an object whose outline centroid is WENT_MARGIN past the edge (the camera's centroid error);
          queued    every other object: still on the feed belt, possibly overhanging;
          just gone a gone object within JUST_WENT of the edge: a release has put something over (starts the
                    beam-miss clock);
          across    a gone object still across the edge: jogged if the most advanced one has not moved 2 %% of
                    feeder_stall_s in feeder_stall_s (it hangs);
          release   lane rule: every gone object's rear past the lane entry; predictive rule: every gone object
                    short of the lane entry has a speed from its track and is predicted out in time (as 5'),
                    none lies across the beam; and in both, every object from STAGE_REACH behind the edge to the
                    lane entry is seen with confidence -- an object it cannot vouch for holds the release;
          hang      a release that ended on the beam-miss fallback left a lump hanging on the edge (it went but
                    did not drop far enough to cut the beam). The camera may not tell it from the next lump
                    touching it (one blob). So no release until the beam has seen it: jog at creep until the
                    beam is cut, at most JOG_MAX_S (seed 4001: the next release started under a merged blob);
          dead beam the camera sees an object pass wholly beyond the beam after a release that never cut it;
                    twice in a row: the beam is dead (simulate raises the alarm)."""
        W, x1, m, bx = self.cfg['feeder_stall_s'], self.g['x1'], WENT_MARGIN, self.g['beam']['x']
        gone = [o for o in view.values() if o['cx'] > x1 + m]
        q = [o for o in view.values() if o['cx'] <= x1 + m]
        just = [o for o in gone if o['cx'] < x1 + JUST_WENT]
        across = [o for o in gone if o['x0'] < x1 + CLEAR]
        h = self.across_hist
        h.append((t, max((o['cx'] for o in across), default=None)))
        while len(h) > 2 and h[1][0] < t - W - .02:
            h.pop(0)
        if self.releases:
            rel = self.releases[-1]
            if beam_cut and not rel.get('beam_seen'):
                rel['beam_seen'] = True
                self.miss_streak = 0
            # an object wholly past the beam after a release that never cut it: the beam missed it
            if 't_first_s' in rel and not rel.get('beam_seen') and not rel.get('passed_unseen') \
                    and any(bx + .02 < o['x0'] < bx + .30 for o in gone):
                rel['passed_unseen'] = round(t, 3)
                self.miss_streak += 1
        if self.phase == 'feeding':
            rel = self.releases[-1]
            if just and 't_first_s' not in rel:
                rel['t_first_s'] = round(t, 3)
                self.events.append(dict(t_s=round(t, 3), event='released', release=rel['release']))
            if self.jog == 'hang':
                if beam_cut or t - self.jog_t0 > JOG_MAX_S:
                    self.jog, self.hang = None, False
                    self._stop(t, 'jog_done' if beam_cut else 'jog_timeout')
            elif self.jog is not None:
                if not across:
                    self.jog = None
                    self._stop(t, 'jog_done')
            elif beam_cut:
                self._stop(t, 'beam')
            elif 't_first_s' in rel and t - rel['t_first_s'] - self.miss_shift > self.beam_miss_s:
                self.counts['beam_missed'] += 1
                self.hang = True                        # it went and the beam has not seen it: it hangs
                self._stop(t, 'beam_missed')
            elif not q and 't_first_s' not in rel:
                self._stop(t, 'feed_belt_empty')
            elif q and self.goal == 1. and max(o['cx'] for o in q) > x1 - CREEP_ZONE:
                self.goal = self.creep
                rel['t_creep_s'] = round(t, 3)
        elif self.phase in ('stopped', 'empty'):
            stuck = (across and len(h) > 1 and h[0][0] <= t - W + .02 and None not in (h[0][1], h[-1][1])
                     and h[-1][1] - h[0][1] < .02 * W)
            if self.hang:
                self.jog, self.jog_t0, self.phase, self.goal, self.staging = 'hang', t, 'feeding', self.creep, False
                self.releases[-1]['jogs'] += 1
                self.counts['jogs'] += 1
                self.events.append(dict(t_s=round(t, 3), event='jog', release=self.releases[-1]['release'], why='hang'))
            elif stuck:
                self.jog, self.phase, self.goal, self.staging = 'across', 'feeding', self.creep, False
                self.releases[-1]['jogs'] += 1
                self.counts['jogs'] += 1
                self.events.append(dict(t_s=round(t, 3), event='jog', release=self.releases[-1]['release']))
            elif not q:
                if self.phase != 'empty':
                    self.phase = 'empty'
                    self.events.append(dict(t_s=round(t, 3), event='feed_belt_empty'))
            elif not self._sure(view):
                if self.staging:                        # an object it cannot vouch for: do not move on a guess
                    self.staging, self.goal = False, 0.
                self.counts['unsure_waits'] = self.counts.get('unsure_waits', 0) + 1
            elif self.predict:
                lead = max(o['cx'] for o in q)
                if face_home and not self.staging and lead >= x1 - CREEP_ZONE - STAGE_STOP - STAGE_SLACK \
                        and self._clear_v(gone, q):
                    self.start(t)
                else:
                    self._stage_v(t, lead, bool(across))
            elif all(o['x0'] > self.lane_in for o in gone) and face_home:
                self.start(t)

    def _clear_v(self, gone, q):
        """5' on the cameras' objects: every gone object short of the lane entry out in time."""
        t_clear = 0.
        for o in gone:
            if o['x0'] > self.lane_in:
                continue
            v = o.get('vx')
            if v is None or v < V_STALL or o['x0'] < self.g['beam']['x'] + CLEAR:
                return False
            rear = float(o['x0'])
            face_ahead = rear < self.bend and float(o['y1']) > self.lane_top
            t_clear = max(t_clear, max(0., self.funnel_in - rear) / self.cfg['v_belt']
                          + (self.lane_in - max(rear, self.funnel_in)) / (min(v, V_FACE) if face_ahead else v))
        if t_clear == 0.:
            return True
        k = max(q, key=lambda o: o['cx'])
        x1, g = self.g['x1'], self.g
        d_c = max(0., x1 - k['cx'])
        t_tip = max(0., d_c - CREEP_ZONE) / g['speed_m_s'] + min(d_c, CREEP_ZONE) / g['creep_speed_m_s'] + TIP_S
        t_arrive = t_tip + max(0., self.funnel_in - (x1 + float(k['x1']) - k['cx'])) / self.cfg['v_belt']
        return t_clear + RELEASE_MARGIN_S <= t_arrive

    def _stage_v(self, t, lead, across):
        x1 = self.g['x1']
        if self.staging:
            if lead >= x1 - CREEP_ZONE - STAGE_STOP or across:
                self.staging, self.goal = False, 0.
                self.events.append(dict(t_s=round(t, 3), event='staged', lead_to_edge_m=round(x1 - lead, 3)))
        elif not across and self.phase == 'stopped' and lead < x1 - CREEP_ZONE - STAGE_STOP - STAGE_SLACK:
            self.staging, self.goal = True, 1.
            self.counts['stagings'] += 1
            self.events.append(dict(t_s=round(t, 3), event='staging'))

    def _sure(self, view):
        """Vision only: every object between STAGE_REACH behind the head edge and the lane entry is seen now
        with CONF_OK or better. One the cameras are unsure of holds the release and the staging."""
        return all(o['conf'] >= CONF_OK and not o.get('coasting') for o in view.values()
                   if o['x1'] > self.g['x1'] - STAGE_REACH and o['x0'] < self.lane_in)

    def audit(self, t, com_x):
        """Vision only, for the verification: which true lumps went over the edge in which release (true
        centroid past the edge). com_x: {lump: true centroid x} of the lumps still on the machine."""
        for k, x in com_x.items():
            if k not in self.lumps_went and x > self.g['x1'] and self.releases:
                rel = self.releases[-1]
                self.lumps_went.add(k)
                rel.setdefault('lumps', []).append(k)
                if rel['t_stop_s'] is not None:
                    rel.setdefault('lumps_after_stop', []).append(k)

    # ---- predictive release ----------------------------------------------------------------------
    def _speed(self, k, view):
        """Centroid x-speed: with vision the track's own estimate, else from the camera history (None until
        it spans 0.3 s)."""
        if self.vision:
            return view[k].get('vx')
        h = self.hist[k]
        return (h[-1][1] - h[0][1]) / (h[-1][0] - h[0][0]) if h and h[-1][0] - h[0][0] >= .3 - 1e-9 else None

    def _clear_to_release(self, view, q):
        """Can the next lump go without meeting one released before it in the funnel (see 5')?"""
        t_clear = 0.
        for k in self.released:
            if k not in view or view[k]['x0'] > self.lane_in:
                continue
            v = self._speed(k, view)
            if v is None or v < V_STALL or view[k]['x0'] < self.g['beam']['x'] + CLEAR:
                return False
            rear = float(view[k]['x0'])
            face_ahead = rear < self.bend and float(view[k]['y1']) > self.lane_top
            t_clear = max(t_clear, max(0., self.funnel_in - rear) / self.cfg['v_belt']
                          + (self.lane_in - max(rear, self.funnel_in)) / (min(v, V_FACE) if face_ahead else v))
        if t_clear == 0.:
            return True
        k = max(q, key=lambda j: view[j]['cx'])         # the next to go, by centroid
        x1, g = self.g['x1'], self.g
        d_c = max(0., x1 - view[k]['cx'])
        t_tip = max(0., d_c - CREEP_ZONE) / g['speed_m_s'] + min(d_c, CREEP_ZONE) / g['creep_speed_m_s'] + TIP_S
        nose = float(view[k]['x1']) - view[k]['cx']     # its front ahead of its centroid
        t_arrive = t_tip + max(0., self.funnel_in - (x1 + nose)) / self.cfg['v_belt']
        return t_clear + RELEASE_MARGIN_S <= t_arrive

    def _staged(self, view, q):
        return max(view[k]['cx'] for k in q) >= self.g['x1'] - CREEP_ZONE - STAGE_STOP - STAGE_SLACK

    def _stage(self, t, view, q):
        """Between releases: bring the next lump up to the creep zone, so the next release only creeps."""
        x1 = self.g['x1']
        lead = max(view[k]['cx'] for k in q)
        off_edge = all(k not in view or view[k]['x0'] > x1 + CLEAR for k in self.released)
        if self.staging:
            if lead >= x1 - CREEP_ZONE - STAGE_STOP or not off_edge:
                self.staging, self.goal = False, 0.
                self.events.append(dict(t_s=round(t, 3), event='staged', lead_to_edge_m=round(x1 - lead, 3)))
        elif off_edge and self.phase == 'stopped' and lead < x1 - CREEP_ZONE - STAGE_STOP - STAGE_SLACK:
            self.staging, self.goal = True, 1.
            self.counts['stagings'] += 1
            self.events.append(dict(t_s=round(t, 3), event='staging'))

    def report(self):
        sizes = [len(r['lumps' if self.vision else 'members']) for r in self.releases
                 if r.get('lumps' if self.vision else 'members')]
        return dict(geometry=self.g, releases=self.releases, events=self.events, final_phase=self.phase,
                    next_release_rear_past_x_m=round(self.lane_in, 4), released_order=self.released,
                    never_released=[k for k in range(self.n) if k not in self.released],
                    counts=dict(self.counts, releases=len(sizes), single=sum(s == 1 for s in sizes),
                                lumps_per_release={str(s): sizes.count(s) for s in sorted(set(sizes))}),
                    held_by_station_s=round(self.held_s, 2),
                    **(dict(release='predict', funnel_mouth_x_m=round(self.funnel_in, 4),
                            release_margin_s=RELEASE_MARGIN_S, v_face_m_s=V_FACE) if self.predict else {}),
                    control='run at feeder_speed, creep once the leading centroid is within the creep zone, stop '
                            'when the drop beam is cut; a lump is released once its centroid is past the head edge '
                            '(it tips); ' + ('between releases the next lump is staged at the creep zone; the next '
                                             'release starts once every lump released before is predicted to be '
                                             'out of the funnel (rear past the lane entry) %.1f s before the next '
                                             'one reaches the funnel mouth, and the face is home' % RELEASE_MARGIN_S
                                             if self.predict else
                                             'next release once every released lump is through the funnel (rear '
                                             'past the lane entry) and the face is home'))
